<?php
  require_once("config/connexion.php");
  Connexion::connect();
  require_once("controleur/controleurAuteur.php");
  $action = "lireAuteurs";
  if (isset($_GET["action"]) && in_array($_GET["action"],get_class_methods('ControleurAuteur'))) {
    $action = $_GET["action"];
  }
  controleurAuteur::$action();
?>
