<?php
	$auteur->afficher();
?>
