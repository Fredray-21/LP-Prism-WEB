<?php
	foreach ($tableauAffichage as $ligne) {
		echo $ligne;
	}
?>
